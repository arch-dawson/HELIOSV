// Image Processing Examples

#include "stdafx.h"
#include "ImageProcExamples.h"

int houghLinesEx() // inefficient example
{
	Mat src = imread("G:\\RocketLaunch.jpg");

	Mat dst, cdst;
	Canny(src, dst, 50, 200, 3);
	cvtColor(dst, cdst, CV_GRAY2BGR);

#if 0
	vector<Vec2f> lines;
	HoughLines(dst, lines, 1, CV_PI / 180, 100, 0, 0);

	for (size_t i = 0; i < lines.size(); i++){
		float rho = lines[i][0], theta = lines[i][1];
		Point pt1, pt2;
		double a = cos(theta), b = sin(theta);
		double x0 = a*rho, y0 = b*rho;
		pt1.x = cvRound(x0 + 1000 * (-b));
		pt1.y = cvRound(y0 + 1000 * (a));
		pt2.x = cvRound(x0 - 1000 * (-b));
		pt2.y = cvRound(y0 - 1000 * (a));
		line(cdst, pt1, pt2, Scalar(0, 0, 255), 3, CV_AA);
	}
#else
	vector<Vec4i> lines;
	HoughLinesP(dst, lines, 1, CV_PI / 180, 50, 50, 10);
	for (size_t i = 0; i < lines.size(); i++){
		Vec4i l = lines[i];
		line(cdst, Point(l[0], l[1]), Point(l[2], l[3]), Scalar(0, 0, 255), 3, CV_AA);
	}
#endif
	imshow("source", src);
	imshow("canny", dst);
	imshow("detected lines", cdst);

	waitKey();

	return 0;
}

int houghCircleEx()
{
	ofstream outputFile;
	outputFile.open("G:\\imageProcessingOutput.txt");
	outputFile << "Circle --- Center x --- Center y --- X Distance from Center --- Y Distance from Center\n";
	Mat src = imread("G:\\sun4.png");
	Mat srcGray;
	
	cvtColor(src, srcGray, CV_BGR2GRAY);

	vector<Vec3f> circles;

	// find circles
	HoughCircles(srcGray, circles, CV_HOUGH_GRADIENT, 1, srcGray.rows / 8, 70, 30, 0, 0);

	for (size_t i = 0; i < circles.size(); i++){
		Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
		// write information to output
		outputFile << i+1 << " \t\t" << center.x << " \t\t" << center.y << " \t\t" << src.cols/2 - center.x << " \t\t" << src.rows/2- center.y << " \n";

		// draw circles that were found
		int radius = cvRound(circles[i][2]);
		// circle center
		circle(src, center, 3, Scalar(0, 255, 0), -1, 8, 0);
		// circle outline
		circle(src, center, radius, Scalar(0, 0, 255), 3, 8, 0);
	}

	Point centerVert1(src.cols / 2, 0);
	Point centerVert2(src.cols / 2, src.rows);
	line(src, centerVert1, centerVert2, Scalar(255,0,0), 1);

	Point centerHoriz1(0, src.rows / 2);
	Point centerHoriz2(src.cols, src.rows / 2);
	line(src, centerHoriz1, centerHoriz2, Scalar(255, 0, 0), 1);

	imshow("test", srcGray);
	imshow("Hough Circles", src);

	imwrite("G:\\sunOutput.png", src);

	waitKey(0);

	return 0;
}