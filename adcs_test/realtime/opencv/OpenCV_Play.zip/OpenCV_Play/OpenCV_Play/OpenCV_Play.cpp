// OpenCV_Play.cpp
// Runs through various image analysis examples

#include "stdafx.h"
#include "ImageProcExamples.h"
#include <iostream>
#include <fstream>

using namespace cv;
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	int input;
	cout << "\tOpenCV Playground\n\nChoose an example:\n" << endl;
	cout << "Hough Line Detection: 1\nHough Circle Detection: 2\n";
	cout << "Choice: ";
	cin >> input;
	switch (input)
	{
	case 1:
		houghLinesEx();
		break;
	case 2:
		houghCircleEx();
		break;
	default:
		cout << "Switch default\n";
	}

	return 0;
}