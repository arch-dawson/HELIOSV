// OpenCV_Play.cpp : Defines the entry point for the console application.
//

#ifndef IMAGEPROCEXAMPLES_H
#define IMAGEPROCEXAMPLES_H

#include "stdafx.h"
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include <opencv2\imgproc\imgproc.hpp>

#include <iostream>
#include <fstream>

using namespace cv;
using namespace std;

int houghLinesEx();
int houghCircleEx();

#endif